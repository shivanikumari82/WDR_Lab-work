// App.jsx
// Registration Form using react-hook-form (useForm)
// Includes validation + error messages + submitted data display

import { useForm } from "react-hook-form";
import { useState } from "react";

export default function App() {
  // react-hook-form setup
  const {
    register,          // to register input fields
    handleSubmit,      // handles form submit
    formState: { errors }, // stores validation errors
  } = useForm();

  // State to store submitted data
  const [submittedData, setSubmittedData] = useState(null);

  // Function to run on form submit
  const onSubmit = (data) => {
    setSubmittedData(data); // save user data
  };

  return (
    <div style={{ maxWidth: "400px", margin: "50px auto", fontFamily: "Arial" }}>
      <h2>Registration Form</h2>

      {/* handleSubmit ensures validation */}
      <form onSubmit={handleSubmit(onSubmit)}>

        {/* NAME FIELD */}
        <label>Name:</label>
        <input
          type="text"
          {...register("name", { required: "Name is required" })} // validation
        />
        {/* show error */}
        {errors.name && (
          <p style={{ color: "red" }}>{errors.name.message}</p>
        )}

        <br /><br />

        {/* EMAIL FIELD */}
        <label>Email:</label>
        <input
          type="email"
          {...register("email", {
            required: "Email is required",
            pattern: {
              value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, // email pattern
              message: "Enter a valid email",
            },
          })}
        />
        {/* show error */}
        {errors.email && (
          <p style={{ color: "red" }}>{errors.email.message}</p>
        )}

        <br /><br />

        {/* PASSWORD FIELD */}
        <label>Password:</label>
        <input
          type="password"
          {...register("password", {
            required: "Password is required",
            minLength: {
              value: 6,
              message: "Password must be at least 6 characters",
            },
          })}
        />
        {/* show error */}
        {errors.password && (
          <p style={{ color: "red" }}>{errors.password.message}</p>
        )}

        <br /><br />

        {/* SUBMIT BUTTON */}
        <button type="submit">Register</button>
      </form>

      {/* DISPLAY SUBMITTED DATA */}
      {submittedData && (
        <div style={{ marginTop: "30px" }}>
          <h3>Submitted Data:</h3>
          <p><strong>Name:</strong> {submittedData.name}</p>
          <p><strong>Email:</strong> {submittedData.email}</p>
          <p><strong>Password:</strong> {submittedData.password}</p>
        </div>
      )}
    </div>
  );
}
