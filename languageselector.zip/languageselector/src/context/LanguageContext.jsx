// LanguageContext.js
// Creates a context to store the selected language value

import { createContext } from "react";

const LanguageContext = createContext({
  language: "en", // default language
  setLanguage: () => {},
});

export default LanguageContext;
