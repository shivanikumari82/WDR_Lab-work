// App.jsx
// Wraps all components inside LanguageContext Provider

import { useState } from "react";
import LanguageContext from "./context/LanguageContext";
import LanguageSelector from "./components/LanguageSelector";
import Message from "./components/Message";

export default function App() {
  // Global language state
  const [language, setLanguage] = useState("en");

  return (
    <LanguageContext.Provider value={{ language, setLanguage }}>
      <div style={{ textAlign: "center", padding: "40px" }}>
        <h1>Language Selector Using Context</h1>

        {/* Component for radio language selection */}
        <LanguageSelector />

        {/* Component to show text dynamically */}
        <Message />
      </div>
    </LanguageContext.Provider>
  );
}
