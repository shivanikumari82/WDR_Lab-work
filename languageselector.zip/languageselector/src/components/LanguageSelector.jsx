// LanguageSelector.jsx
// Provides radio buttons to choose language

import { useContext } from "react";
import LanguageContext from "../context/LanguageContext";

export default function LanguageSelector() {
  const { language, setLanguage } = useContext(LanguageContext);

  return (
    <div style={{ marginTop: "20px", fontSize: "18px" }}>
      <h3>Select Language:</h3>

      {/* Radio button for English */}
      <label>
        <input
          type="radio"
          value="en"
          checked={language === "en"}
          onChange={() => setLanguage("en")}
        />
        English
      </label>

      <br />

      {/* Radio button for Hindi */}
      <label>
        <input
          type="radio"
          value="hi"
          checked={language === "hi"}
          onChange={() => setLanguage("hi")}
        />
        Hindi
      </label>

      <br />

      {/* Radio button for French */}
      <label>
        <input
          type="radio"
          value="fr"
          checked={language === "fr"}
          onChange={() => setLanguage("fr")}
        />
        French
      </label>
    </div>
  );
}
