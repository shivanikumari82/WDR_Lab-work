// Message.jsx
// Shows text based on selected language using context

import { useContext } from "react";
import LanguageContext from "../context/LanguageContext";

export default function Message() {
  const { language } = useContext(LanguageContext);

  // Multilingual text mapping
  const messages = {
    en: "Hello! Welcome to our app.",
    hi: "नमस्ते! हमारे ऐप में आपका स्वागत है।",
    fr: "Bonjour! Bienvenue dans notre application.",
  };

  return (
    <div style={{ marginTop: "30px", fontSize: "22px" }}>
      {/* Show text based on selected language */}
      <p>{messages[language]}</p>
    </div>
  );
}
