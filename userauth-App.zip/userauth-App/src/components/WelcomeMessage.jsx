// WelcomeMessage.jsx
// Shows welcome message only if user is logged in

import { useContext } from "react";
import UserContext from "../context/UserContext";

export default function WelcomeMessage() {
  // Consume context values
  const { user } = useContext(UserContext);

  return (
    <div style={{ marginTop: "20px", fontSize: "20px" }}>
      {/* Conditional Rendering */}
      {user.isLoggedIn ? (
        <p>Welcome, <strong>{user.name}</strong>! 🎉</p>
      ) : (
        <p>Please login to continue.</p>
      )}
    </div>
  );
}
