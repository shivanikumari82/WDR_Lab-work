// LoginButton.jsx
// Button that logs the user in and updates global state

import { useContext } from "react";
import UserContext from "../context/UserContext";

export default function LoginButton() {
  const { user, handleLogin } = useContext(UserContext);

  return (
    <>
      {/* Show button only when logged out */}
      {!user.isLoggedIn && (
        <button
          onClick={handleLogin}
          style={{
            padding: "10px 20px",
            fontSize: "18px",
            marginTop: "20px",
            cursor: "pointer",
          }}
        >
          Login
        </button>
      )}
    </>
  );
}
