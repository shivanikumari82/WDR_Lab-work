// App.jsx
// Provides UserContext to the entire app and manages user login state

import { useState } from "react";
import UserContext from "./context/UserContext";
import LoginButton from "./components/LoginButton";
import WelcomeMessage from "./components/WelcomeMessage";

export default function App() {
  // Global user authentication state
  const [user, setUser] = useState({
    isLoggedIn: false,
    name: "",
  });

  // Login function to update global state
  const handleLogin = () => {
    setUser({
      isLoggedIn: true,
      name: "John",
    });
  };

  return (
    // Providing state + updater function globally
    <UserContext.Provider value={{ user, handleLogin }}>
      <div style={{ padding: "40px", textAlign: "center" }}>
        <h1>User Authentication Using Context</h1>

        {/* Show welcome message or login button */}
        <WelcomeMessage />

        <LoginButton />
      </div>
    </UserContext.Provider>
  );
}
