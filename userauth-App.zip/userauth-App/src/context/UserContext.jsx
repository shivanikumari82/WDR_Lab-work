// UserContext.js
// Creates a global context for authentication state

import { createContext } from "react";

// Default context value
const UserContext = createContext({
  isLoggedIn: false,
  name: "",
});

export default UserContext;
