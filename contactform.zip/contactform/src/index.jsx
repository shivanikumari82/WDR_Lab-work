// index.js
import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css"; // optional if using custom CSS

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
