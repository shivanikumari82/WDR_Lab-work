// App.jsx
// Contact Form using react-hook-form
// Demonstrates: reset(), setValue(), maintaining form control

import { useForm } from "react-hook-form";

export default function App() {
  // useForm() hook
  const { register, handleSubmit, setValue, reset } = useForm();

  // On form submit
  const onSubmit = (data) => {
    alert("Form Submitted!\n" + JSON.stringify(data, null, 2));
  };

  // Function: Prefill Example Data using setValue()
  const fillExampleData = () => {
    setValue("fullName", "Shivani Kumari");
    setValue("message", "Hello! This is a sample message.");
  };

  // Function: Reset form using reset()
  const resetForm = () => {
    reset(); // clears all fields
  };

  return (
    <div style={{ maxWidth: "400px", margin: "50px auto", fontFamily: "Arial" }}>
      <h2>Contact Form</h2>

      {/* handleSubmit ensures proper form validation and handling */}
      <form onSubmit={handleSubmit(onSubmit)}>

        {/* FULL NAME FIELD */}
        <label>Full Name:</label>
        <input
          type="text"
          {...register("fullName", { required: true })}
        />

        <br /><br />

        {/* MESSAGE FIELD */}
        <label>Message:</label>
        <textarea
          rows="4"
          {...register("message", { required: true })}
        ></textarea>

        <br /><br />

        {/* SUBMIT BUTTON */}
        <button type="submit">Submit</button>

        &nbsp;&nbsp;

        {/* RESET BUTTON */}
        <button type="button" onClick={resetForm}>
          Reset
        </button>

        &nbsp;&nbsp;

        {/* PREFILL EXAMPLE DATA BUTTON */}
        <button type="button" onClick={fillExampleData}>
          Fill Example Data
        </button>

      </form>
    </div>
  );
}
